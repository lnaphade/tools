# CVE-2021-1675(PrintNightmare)
system shell poc for CVE-2021-1675 (Windows Print Spooler Elevation of Privilege)

#### credit: Zhiniang Peng (@edwardzpeng) & Xuefeng Li (@lxf02942370)

#### Ref: https://github.com/afwu/PrintNightmare

#### windows 10

![test1](https://github.com/sailay1996/PrintNightmare-LPE/blob/main/img/win10PN.jpg)

#### windows server 2012

![test2](https://github.com/sailay1996/PrintNightmare-LPE/blob/main/img/win2012PN.jpg)

##### Credit to all researcher who find out this bug.


[@404death](https://twitter.com/404death)

