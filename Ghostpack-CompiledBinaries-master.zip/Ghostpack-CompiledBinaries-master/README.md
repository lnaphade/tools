# GhostPack-Compiled Binaries
Compiled binaries for [GhostPack](https://github.com/GhostPack) authored by [@harmj0y](https://twitter.com/harmj0y)

I will try to update them whenever new features/modifications are added to the original repos.

Chrome is marking the page as dangerous because it 'thinks' the repo includes pages that install unwanted or malicious software. I bet some automated program scanned the page, noticed security tools and marked it as unsafe.
