GO
PRINT 'This is a test';
DECLARE @TestVariable VARCHAR(1);
GO
PRINT 'Of some SQL'; DECLARE @TestVariable VARCHAR(2);

  GO
  
  
    
 DECLARE @TestVariable VARCHAR(3);
 
-- GO  

  GO  DECLARE @TestVariable VARCHAR(4);
  
DECLARE @TestVariable VARCHAR(5);

GO 3

DECLARE @TestVariable VARCHAR(6);

GO	    	4 

DECLARE @TestVariable VARCHAR(7);

GO     
57

DECLARE @TestVariable VARCHAR(8);

 GO 55  DECLARE @TestVariable VARCHAR(9);
DECLARE @TestVariable VARCHAR(10);
GO 555
DECLARE @TestVariable VARCHAR(11);
GO 432     

DECLARE @TestVariable VARCHAR(12);

DECLARE @TestVariable VARCHAR(13); GO DECLARE @TestVariable VARCHAR(14);

DECLARE @TestVariable VARCHAR(15);

GO
GO
GO /* comment error */
GO
 /* comment
 error 2 */ GO
GO
GO

SELECT '7';DECLARE @TestVariable VARCHAR(7);
/*  no-error
  comment A */  /*  no-error
  comment B */ GO 

GO

SELECT 1;

GO
Go
GO
gO
GO