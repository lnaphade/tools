SELECT 1 AS [Batch 1];
SELECT 2 AS [Batch 1];

GO
SELECT 3 AS [Batch 2];
GO


SELECT 4 AS [Batch 3];
