SELECT * FROM #SimpleSqlExec;

SELECT 2 AS [Result Set #];
