SELECT 99 AS [Test-5-times];
GO 5
