CREATE TABLE #SimpleSqlExec (Col1 INT);
INSERT INTO #SimpleSqlExec (Col1) VALUES (1);

SELECT 1 AS [File #];
