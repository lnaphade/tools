GO
SELECT '1 - This is a test';
DECLARE @TestVariable VARCHAR(1);
GO
SELECT '2 - Of some SQL'; DECLARE @TestVariable VARCHAR(2);

  GO
  
  
    SELECT '3';
 DECLARE @TestVariable VARCHAR(3);
 
-- GO  

  GO  -- comment
  SELECT '4';
DECLARE @TestVariable VARCHAR(4);

GO 3

SELECT '5';DECLARE @TestVariable VARCHAR(5);

GO	    	4 

--*--SELECT '6'; DECLARE @TestVariable VARCHAR(6);


/*  no-error
  comment */ --*--GO 

--*--SELECT '7';DECLARE @TestVariable VARCHAR(7);
/*  no-error
  comment A *//*  no-error
  comment B */ --*--GO 

SELECT '8';DECLARE @TestVariable VARCHAR(8);

SELECT CONCAT(name, N'|', 

/*   
/ * embedded block comment  * /
*/ [object_id], N'|', principal_id, N'|', create_date), CONVERT(BINARY(20), HASHBYTES(N'SHA1', CONCAT(name, N'|', [object_id], N'|', principal_id, N'|', create_date))), * FROM sys.objects;
	go
 GO 55
SELECT '9';DECLARE @TestVariable VARCHAR(9);
PRINT 'ssssss';
GO 0003
SELECT '10';DECLARE @TestVariable VARCHAR(10);
PRINT 'ssssss';
GO 002     

--*--SELECT '11';DECLARE @TestVariable VARCHAR(11);

--*--/*   comment 1 */ GO 5 -- comment 2

--*--SELECT '12';DECLARE @TestVariable VARCHAR(12);

--*--/*   comment 3 */ GO -- comment 4

SELECT '13';DECLARE @TestVariable VARCHAR(13);

GO
GO

GO

SELECT '14';DECLARE @TestVariable VARCHAR(14);

GO
Go
GO
gO
GO