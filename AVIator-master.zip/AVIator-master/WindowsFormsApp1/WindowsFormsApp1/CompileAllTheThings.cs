﻿using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Text;


namespace AvIator
{
    class CompileAllTheThings
    {
        String compilerCode;

        public CompileAllTheThings(String payload, String key)
        {
            compilerCode = @"";
        }



    }
}
